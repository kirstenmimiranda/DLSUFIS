<?php

define('EMAIL', 'dlsuccsams@gmail.com');
define('PASS', 'DLSU12345678');

?>

