function saveApage(){
    var Instructiona1 = $("input[name='Instructiona1']:checked").val();
    var Instructiona2 = $("input[name='Instructiona2']:checked").val();
    var Instructiona3 = $("input[name='Instructiona3']:checked").val();
    var Instructiona4a = $("input[name='Instructiona4a']:checked").val();
    var Instructiona4b = $("input[name='Instructiona4b']:checked").val();
    var Instructiona4c = $("input[name='Instructiona4c']:checked").val();
    var Instructiona4d = $("input[name='Instructiona4d']:checked").val();
    var Instructiona5a = $("input[name='Instructiona5a']:checked").val();
    var Instructiona5b = $("input[name='Instructiona5b']:checked").val();
    var Instructiona5c = $("input[name='Instructiona5c']:checked").val();
    var Instructiona5d = $("input[name='Instructiona5d']:checked").val();
    var Instructiona5e = $("input[name='Instructiona5e']:checked").val();
    var Instructiona5f = $("input[name='Instructiona5f']:checked").val();
    var Instructiona5g = $("input[name='Instructiona5g']:checked").val();
    var Instructiona6 = $("input[name='Instructiona6']:checked").val();
    var Instructiona7 = $("input[name='Instructiona7']:checked").val();
    var Instructiona8 = $("input[name='Instructiona8']:checked").val();
    var Instructiona9 = $("input[name='Instructiona9']:checked").val();
    var Instructiona10 = $("input[name='Instructiona10']:checked").val();
    var Instructiona11 = $("input[name='Instructiona11']:checked").val();
    var Instructiona12 = $("input[name='Instructiona12']:checked").val();
    var Instructiona13 = $("input[name='Instructiona13']:checked").val();
    var Instructiona14 = $("input[name='Instructiona14']:checked").val();
    var Instructiona15 = $("input[name='Instructiona15']:checked").val();
    var Instructiona16 = $("input[name='Instructiona16']:checked").val();
    var Instructiona17 = $("input[name='Instructiona17']:checked").val();
    var Instructiona18 = $("input[name='Instructiona18']:checked").val();
    var Instructiona19 = $("input[name='Instructiona19']:checked").val();
    var Instructiona20 = $("input[name='Instructiona20']:checked").val();
    var Instructiona21 = $("input[name='Instructiona21']:checked").val();
    var Instructiona22a = $("input[name='Instructiona22a']:checked").val();
    var Instructiona22b = $("input[name='Instructiona22b']:checked").val();
    var Instructiona22c = $("input[name='Instructiona22c']:checked").val();
    var Instructiona22d = $("input[name='Instructiona22d']:checked").val();
    var Instructiona22e = $("input[name='Instructiona22e']:checked").val();
    var Instructiona23 = $("input[name='Instructiona23']:checked").val();
    var Instructiona24 = $("input[name='Instructiona24']:checked").val();
    var Instructiona25 = $("input[name='Instructiona25']:checked").val();
    var AEvala = $("input[name='AEvala']:checked").val();
    var AEvalb = $("input[name='AEvalb']:checked").val();
    var AEvalc = $("input[name='AEvalc']:checked").val();
    var AEvald = $("input[name='AEvald']:checked").val();
    var AEvale = $("input[name='AEvale']:checked").val();
    var AEvalf = $("input[name='AEvalf']:checked").val();
    var AEvalg = $("input[name='AEvalg']:checked").val();


    if(Instructiona1 == null)
        Instructiona1 = '';

    if(Instructiona2 == null)
        Instructiona2 = '';

    if(Instructiona3 == null)
        Instructiona3 = '';

    if(Instructiona4a == null)
        Instructiona4a = '';

    if(Instructiona4b == null)
        Instructiona4b = '';

    if(Instructiona4c == null)
        Instructiona4c = '';

    if(Instructiona4d == null)
        Instructiona4d = '';

    var Instructiona4 = Instructiona4a + Instructiona4b + Instructiona4c + Instructiona4d;

    if(Instructiona5a == null)
        Instructiona5a = '';

    if(Instructiona5b == null)
        Instructiona5b = '';

    if(Instructiona5c == null)
        Instructiona5c = '';

    if(Instructiona5d == null)
        Instructiona5d = '';

    if(Instructiona5e == null)
        Instructiona5e = '';

    if(Instructiona5f == null)
        Instructiona5f = '';

    if(Instructiona5g == null)
        Instructiona5g = '';

    var Instructiona5 = Instructiona5a + Instructiona5b + Instructiona5c + Instructiona5d + Instructiona5e + Instructiona5f + Instructiona5g;

    if(Instructiona6 == null)
        Instructiona6 = '';

    if(Instructiona7 == null)
        Instructiona7 = '';

    if(Instructiona8 == null)
        Instructiona8 = '';

    if(Instructiona9 == null)
        Instructiona9 = '';

    if(Instructiona10 == null)
        Instructiona10 = '';

    if(Instructiona11 == null)
        Instructiona11 = '';

    if(Instructiona12 == null)
        Instructiona12 = '';

    if(Instructiona13 == null)
        Instructiona13 = '';

    if(Instructiona14 == null)
        Instructiona14 = '';

    if(Instructiona15 == null)
        Instructiona15 = '';

    if(Instructiona16 == null)
        Instructiona16 = '';

    if(Instructiona17 == null)
        Instructiona17 = '';

    if(Instructiona18 == null)
        Instructiona18 = '';

    if(Instructiona19 == null)
        Instructiona19 = '';

    if(Instructiona20 == null)
        Instructiona20 = '';

    if(Instructiona21 == null)
        Instructiona21 = '';

    if(Instructiona22a == null)
        Instructiona22a = '';

    if(Instructiona22b == null)
        Instructiona22b = '';

    if(Instructiona22c == null)
        Instructiona22c = '';

    if(Instructiona22d == null)
        Instructiona22d = '';

    if(Instructiona22e == null)
        Instructiona22e = '';

    var Instructiona22 = Instructiona22a + Instructiona22b + Instructiona22c + Instructiona22d + Instructiona22e;

    if(Instructiona23 == null)
        Instructiona23 = '';

    if(Instructiona24 == null)
        Instructiona24 = '';

    if(Instructiona25 == null)
        Instructiona25 = '';

    if(AEvala == null)
        AEvala = '';

    if(AEvalb == null)
        AEvalb = '';

    if(AEvalc == null)
        AEvalc = '';

    if(AEvald == null)
        AEvald = '';

    if(AEvale == null)
        AEvale = '';

    if(AEvalf == null)
        AEvalf = '';

    if(AEvalg == null)
        AEvalg = '';

    $.ajax({
        type: 'POST',
        url: "ajax/SaveInstructionEvalA.php",
        data:{
            Instructiona1: Instructiona1,
            Instructiona2: Instructiona2,
            Instructiona3: Instructiona3,
            Instructiona4: Instructiona4,
            Instructiona5: Instructiona5,
            Instructiona6: Instructiona6,
            Instructiona7: Instructiona7,
            Instructiona8: Instructiona8,
            Instructiona9: Instructiona9,
            Instructiona10: Instructiona10,
            Instructiona11: Instructiona11,
            Instructiona12: Instructiona12,
            Instructiona13: Instructiona13,
            Instructiona14: Instructiona14,
            Instructiona15: Instructiona15,
            Instructiona16: Instructiona16,
            Instructiona17: Instructiona17,
            Instructiona18: Instructiona18,
            Instructiona19: Instructiona19,
            Instructiona20: Instructiona20,
            Instructiona21: Instructiona21,
            Instructiona22: Instructiona22,
            Instructiona23: Instructiona23,
            Instructiona24: Instructiona24,
            Instructiona25: Instructiona25,
            AEvala: AEvala,
            AEvalb: AEvalb,
            AEvalc: AEvalc,
            AEvald: AEvald,
            AEvale: AEvale,
            AEvalf: AEvalf,
            AEvalg: AEvalg
        },
        success: function(result){
            alert("Instruction: Section A Saved");
        }
    });
}

function saveBpage(){
    var B1 = $("input[name='Instructionb1']:checked").val();
    var B2 = $("input[name='Instructionb2']:checked").val();
    var B3 = $("input[name='Instructionb3']:checked").val();
    var B4 = $("input[name='Instructionb4']:checked").val();
    var B5 = $("input[name='Instructionb5']:checked").val();
    var B6 = $("input[name='Instructionb6']:checked").val();
    var B7 = $("input[name='Instructionb7']:checked").val();
    var B8 = $("input[name='Instructionb8']:checked").val();
    var B9 = $("input[name='Instructionb9']:checked").val();
    var B10 = $("input[name='Instructionb10']:checked").val();
    var B11 = $("input[name='Instructionb11']:checked").val();
    var B12 = $("input[name='Instructionb12']:checked").val();
    var B13 = $("input[name='Instructionb13']:checked").val();
    var B14 = $("input[name='Instructionb14']:checked").val();
    var B15 = $("input[name='Instructionb15']:checked").val();
    var B16 = $("input[name='Instructionb16']:checked").val();
    var B17 = $("input[name='Instructionb17']:checked").val();
    var B18 = $("input[name='Instructionb18']:checked").val();
    var Ba = $("input[name='BEvala']:checked").val();
    var Bb = $("input[name='BEvalb']:checked").val();
    var Bc = $("input[name='BEvalc']:checked").val();
    var Bd = $("input[name='BEvald']:checked").val();
    var Be = $("input[name='BEvale']:checked").val();
    var Bf = $("input[name='BEvalf']:checked").val();
    var Bg = $("input[name='BEvalg']:checked").val();
    


    $.ajax({
        type: 'POST',
        url: "ajax/SaveInstructionEvalB.php",
        data:{
            B1: B1,
            B2: B2,
            B3: B3,
            B4: B4,
            B5: B5,
            B6: B6,
            B7: B7,
            B8: B8,
            B9: B9,
            B10: B10,
            B11: B11,
            B12: B12,
            B13: B13,
            B14: B14,
            B15: B15,
            B16: B16,
            B17: B17,
            B18: B18,
            Ba: Ba,
            Bb: Bb,
            Bc: Bc,
            Bd: Bd,
            Be: Be,
            Bf: Bf,
            Bg: Bg,


        },
        success: function(result){
            alert("Instruction: Section B Saved");
            
        }
    });
}

function saveCpage(){

    var B1 = $("input[name='instructionc1']:checked").val();
    var B2 = $("input[name='instructionc2']:checked").val();
    var B3 = $("input[name='instructionc3']:checked").val();
    var B4 = $("input[name='instructionc4']:checked").val();
    var B5 = $("input[name='instructionc5']:checked").val();
    var B6 = $("input[name='instructionc6']:checked").val();
    var B7 = $("input[name='instructionc7']:checked").val();
    var B8 = $("input[name='instructionc8']:checked").val();
    var B9 = $("input[name='instructionc9']:checked").val();
    var B10 = $("input[name='instructionc10']:checked").val();
    var B11 = $("input[name='instructionc11']:checked").val();
    var B12 = $("input[name='instructionc12']:checked").val();
    var Ba = $("input[name='IEvalCa']:checked").val();
    var Bb = $("input[name='IEvalCb']:checked").val();
    var Bc = $("input[name='IEvalCc']:checked").val();
    var Bd = $("input[name='IEvalCd']:checked").val();

    $.ajax({
        type: 'POST',
        url: "ajax/SaveInstructionEvalC.php",
        data:{
            B1: B1,
            B2: B2,
            B3: B3,
            B4: B4,
            B5: B5,
            B6: B6,
            B7: B7,
            B8: B8,
            B9: B9,
            B10: B10,
            B11: B11,
            B12: B12,
            Ba: Ba,
            Bb: Bb,
            Bc: Bc,
            Bd: Bd
        },
        success: function(result){
            alert("Instuction: Section C Saved");
        }
    });
}

function saveDpage(){

    var B1 = $("input[name='instructionAD1']:checked").val();
    var B2 = $("input[name='instructionAD2']:checked").val();
    var B3 = $("input[name='instructionAD3']:checked").val();
    var Ba = $("input[name='instructionDEa']:checked").val();
    var Bb = $("input[name='instructionDEb']:checked").val();
    var Bc = $("input[name='instructionDEc']:checked").val();
    var Bd = $("input[name='instructionDEd']:checked").val();

    $.ajax({
        type: 'POST',
        url: "ajax/SaveInstructionEvalD.php",
        data:{
            B1: B1,
            B2: B2,
            B3: B3,
            Ba: Ba,
            Bb: Bb,
            Bc: Bc,
            Bd: Bd
        },
        success: function(result){
            alert("Instuction: Section D Saved");
        }
    });
}

function saveEpage(){
    var B1 = $("input[name='EInstructionAnalysis1']:checked").val();
    var B2 = $("input[name='EInstructionAnalysis2']:checked").val();
    var B3 = $("input[name='EInstructionAnalysis3']:checked").val();
    var B4 = $("input[name='EInstructionAnalysis4']:checked").val();
    var Ba = $("input[name='EInstructionEvala']:checked").val();
    var Bb = $("input[name='EInstructionEvalb']:checked").val();
    var Bc = $("input[name='EInstructionEvalc']:checked").val();

    $.ajax({
        type: 'POST',
        url: "ajax/SaveInstructionEvalE.php",
        data:{
            B1: B1,
            B2: B2,
            B3: B3,
            B4: B4,
            Ba: Ba,
            Bb: Bb,
            Bc: Bc

        },
        success: function(result){
            alert("Instruction: Section E Saved");
            
        }
    });
}

function saveFpage(){
    var B1 = $("input[name='FInstructionAnalysis1']:checked").val();
    var B2 = $("input[name='FInstructionAnalysis2']:checked").val();
    var B3 = $("input[name='FInstructionAnalysis3']:checked").val();
    var B4 = $("input[name='FInstructionAnalysis4']:checked").val();
    var B5 = $("input[name='FInstructionAnalysis5']:checked").val();
    var B6 = $("input[name='FInstructionAnalysis6']:checked").val();
    var B7 = $("input[name='FInstructionAnalysis7']:checked").val();

    var Ba = $("input[name='FInstructionEvala']:checked").val();
    var Bb = $("input[name='FInstructionEvalb']:checked").val();

    $.ajax({
        type: 'POST',
        url: "ajax/SaveInstructionEvalF.php",
        data:{
            B1: B1,
            B2: B2,
            B3: B3,
            B4: B4,
            B5: B5,
            B6: B6,
            B7: B7,
            Ba: Ba,
            Bb: Bb,
            

        },
        success: function(result){
            alert("Instruction: Section F Saved");
            console.log(result);
            
        }
    });
}
function saveGpage(){
    var B1 = $("input[name='GInstructionAnalysis1']:checked").val();
    var B2 = $("input[name='GInstructionAnalysis2']:checked").val();
    var B3 = $("input[name='GInstructionAnalysis3']:checked").val();

    var Ba = $("input[name='GInstructionEvala']:checked").val();
    var Bb = $("input[name='GInstructionEvalb']:checked").val();

    $.ajax({
        type: 'POST',
        url: "ajax/SaveInstructionEvalG.php",
        data:{
            B1: B1,
            B2: B2,
            B3: B3,
            Ba: Ba,
            Bb: Bb,
            

        },
        success: function(result){
            alert("Instruction: Section G Saved");
            console.log(result);
            
        }
    });
}

