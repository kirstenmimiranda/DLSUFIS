<?php
$dbc=mysqli_connect('localhost','root', null ,'ccsfif');

if (!$dbc) {
 die('Could not connect: '.mysql_error());
}

?>