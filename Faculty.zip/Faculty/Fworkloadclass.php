<!DOCTYPE html>
<html lang="en">

<?php
        session_start();
        require_once('../mysql_connect.php');
        if($_SESSION['POSITION_ID']!="P0004" && $_SESSION['POSITION_ID']!="P0003" ) {
          header("Location: http://".$_SERVER['HTTP_HOST'].  dirname($_SERVER['PHP_SELF'])."../login.php"); 
        }
		if(isset($_POST['delete']))
		{
		$query="UPDATE `ccsfif`.`document` SET `isArchived`='1' WHERE `ID`='{$_POST['delete']}';";
		$result=mysqli_query($dbc,$query);
		echo $query;
		}
       $titleid = $_GET['viewworkload'];
?>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>CCS Accreditation Management System </title>

  <!-- Favicons -->
  <link href="../../img/logodlsu.png" rel="icon">
  <link href="../../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="../../css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="../../lib/gritter/css/jquery.gritter.css" />
    <link rel="stylesheet" type="text/css" href="../../lib/bootstrap-datepicker/css/datepicker.css" />
  <!-- Custom styles for this template -->
  <link href="../../css/style.css" rel="stylesheet">
  <link href="../../css/style-responsive.css" rel="stylesheet">
  <script src="../../lib/chart-master/Chart.js"></script>

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
      <?php
      require_once("sidetopbar.php");
      ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->

    <section id="main-content">
      <section class="wrapper site-min-height">
          <div class="row mt">
          <div class="col-lg-12">
            
             <?php 
            $title = "SELECT 
                            sy.syid, sy.schoolyearstart, sy.schoolyearend,cr.coursename, cr.courseid, f.ffname, f.flname, cs.isArchived, cs.documentID, cs.documentid, t.termid
                        FROM
                            class cs,
                            course cr,
                            schoolyear sy,
                            faculty f,
							term t
                        WHERE
                            cr.courseid = cs.courseid
                                AND sy.syid = cs.schoolyear
								AND t.termid = cs.termid
                                AND cs.fid=f.fid
                                AND classid= $titleid";
								
              
               $qr = mysqli_query($dbc, $title);
            
            $display = mysqli_fetch_assoc($qr);
              
              echo "<center><h2> {$display['coursename']} <br> (SY {$display['schoolyearstart']} - {$display['schoolyearend']} TERM {$display['termid']})</center></h2>"; 
			  $ssy = $display['syid'];
			  $ttid = $display['termid'];
			  $start = $display['schoolyearstart'];
			  $end = $display['schoolyearend'];
			  
            ?>
          
          <h1></h1>
        
            <div class="col-lg-12 mt">
            <div class="row content-panel">
              <div class="panel-heading">
                <ul class="nav nav-tabs nav-justified">
				<?php
				
					$query2 = "SELECT * FROM ccsfif.course_has_material where courseID = '{$display['courseid']}'";
					$qr2 = mysqli_query($dbc, $query2);
					$once = true;
					$ctr = 0;
					while($row=mysqli_fetch_array($qr2,MYSQLI_ASSOC))
					{
						$matid = $row['workload_material_id'];
						$query3 = "SELECT * FROM ccsfif.course_material where course_material_ID = '$matid';";
						$qr3 = mysqli_query($dbc, $query3);
						
						while($row2=mysqli_fetch_array($qr3,MYSQLI_ASSOC))
						{
							$ctr = $ctr + 1;
							$matname = $row2['course_material_name'];
							if($once)
							{
								echo '<li class="active">';
								echo '<a data-toggle="tab" href="#'.$ctr.'a">'.$matname.'</a>';
								echo '</li>';
								$once = false;
							}
							else
							{
								echo '<li>';
								echo '<a data-toggle="tab" href="#'.$ctr.'a">'.$matname.'</a>';
								echo '</li>';
							}
						}
					}
				 ?>
                </ul>
              </div>
             
            
                
            <div class="panel-body">
                <div class="tab-content">
                         
					<?php
					$tt ="SELECT fid 
                          FROM faculty 
                          where username = '{$_SESSION['username']}' ";

                    $ttr = mysqli_query($dbc, $tt);

                    $fid = mysqli_fetch_array($ttr);

                    $fidd= $fid['fid'];
					
					$query4 = "SELECT * FROM ccsfif.course_has_material where courseID = '{$display['courseid']}'";
					$qr4 = mysqli_query($dbc, $query4);
					$once2 = true;
					$ctr2 = 0;
					$none = true;
					while($row4=mysqli_fetch_array($qr4,MYSQLI_ASSOC))
					{
						$matid = $row4['workload_material_id'];
						$query5 = "SELECT * FROM ccsfif.course_material where course_material_ID = '$matid';";
						$qr5 = mysqli_query($dbc, $query5);
						
						while($row5=mysqli_fetch_array($qr5,MYSQLI_ASSOC))
						{
							$ctr2 = $ctr2 + 1;
							$matname2 = $row5['course_material_name'];
							if($once2)
							{
								echo '<div id="'.$ctr2.'a" class="tab-pane active">';
									echo '<center><h2>'.$matname2.'</h2></center>';
									echo '<table class="table table-striped table-advance">';
										echo '<thead>';
											echo '<tr>';
											echo '	<th class="hidden-phone"><i class=""></i>Evidences</th>';
											echo '	<th class="hidden-phone"><i class=""></i>Date Uploaded</th>';
											echo '</tr>';
										echo '</thead>';
										
										echo '<tbody>';
										
										$query6 = "SELECT * FROM ccsfif.course_material_document where fid = $fidd and syid = ".$ssy." and termid = ".$ttid." and isarchived = 0 and course_material_id = $matid";
										$qr6 = mysqli_query($dbc, $query6);
										while($row6=mysqli_fetch_array($qr6,MYSQLI_ASSOC))
										{
											echo "<td>";
											echo $row6['file_name'];
											echo "</td>";
											echo "<td>";
											echo $row6['date_modified'];
											echo "</td>";
										}
										echo '</tbody>';
									echo '</table>';
								echo '</div> ';
								$once2 = false;
								$none = false;
							}
							else
							{
								echo '<div id="'.$ctr2.'a" class="tab-pane">';
									echo '<center><h2>'.$matname2.'</h2></center>';
									echo '<table class="table table-striped table-advance">';
										echo '<thead>';
											echo '<tr>';
											echo '	<th class="hidden-phone"><i class=""></i>Evidences</th>';
											echo '	<th class="hidden-phone"><i class=""></i>Date Uploaded</th>';
											echo '</tr>';
										echo '</thead>';
										
										echo '<tbody>';
										
										$query6 = "SELECT * FROM ccsfif.course_material_document where fid = $fidd and syid = ".$ssy." and termid = ".$ttid." and isarchived = 0 and course_material_id = $matid";
										$qr6 = mysqli_query($dbc, $query6);
										while($row6=mysqli_fetch_array($qr6,MYSQLI_ASSOC))
										{
											echo "<td>";
											echo $row6['file_name'];
											echo "</td>";
											echo "<td>";
											echo $row6['date_modified'];
											echo "</td>";
										}
										echo '</tbody>';
									echo '</table>';
								echo '</div> ';
							}
						}
					}
					?>
                  </div>
            </div>
			<?php 

function File_Size($size)
{
    if($size > 104876){
        return $return_size=sprintf("%01.2f",$size / 1048576)." Mb";
    }elseif($size > 1024){
        return $return_size=sprintf("%01.2f",$size / 1024)." Kb";
    }else{
        return $return_size=$size." Bytes";
    }

}
            ?>
			
			
            </div>
            </div>
            </div>
        </div>
                  <!-- /row -->
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
 
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        </div>
        <a href="../../index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../../lib/jquery/jquery.min.js"></script>

  <script src="../../lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../../lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../lib/jquery.scrollTo.min.js"></script>
  <script src="../../lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="../../lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="../../lib/common-scripts.js"></script>
  <script type="text/javascript" src="../../lib/gritter/js/jquery.gritter.js"></script>
  <script type="text/javascript" src="../../lib/gritter-conf.js"></script>
  <!--script for this page-->
  <script src="../../lib/sparkline-chart.js"></script>
  <script src="../../lib/zabuto_calendar.js"></script>

  <script type="application/javascript">
    $(document).ready(function() {
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });
    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
  </script>
<script>
$("#4").addClass("active");
    </script>
</body>

</html>
