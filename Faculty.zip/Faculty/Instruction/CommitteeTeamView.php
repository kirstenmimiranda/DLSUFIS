<!DOCTYPE html>
<html lang="en">

<?php
        session_start();
        require_once('../../mysql_connect.php');
        if($_SESSION['POSITION_ID']!="P0004" && $_SESSION['POSITION_ID']!="P0003" ) {
          header("Location: http://".$_SERVER['HTTP_HOST'].  dirname($_SERVER['PHP_SELF'])."../login.php"); 
        }
       
?>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>CCS- Accreditation Management System</title>

    <!-- Favicons -->
  <link href="../../../img/logodlsu.png" rel="icon">
  <link href="../../../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../../../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="../../../css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="../../../lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="../../../css/style.css" rel="stylesheet">
  <link href="../../../css/style-responsive.css" rel="stylesheet">
  <script src="../../../lib/chart-master/Chart.js"></script>
  
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>    

</head>

<body>
  <section id="container">

    <?php
      require_once("sidetopbar.php");
      ?>
      <!--main content start-->
      <section id="main-content">
      <section class="wrapper">
          <H1><CENTER>Committee Team for Instruction</CENTER></H1>
          <div class="col-md-12">
            <div class="content-panel">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"><b>Executive Committee</b></label>
                  <div class="col-sm-8">
                      <?php 
                            $q = "SELECT 
                                        idCommittee_Head_Executive as 'id',
                                        GETFACULTYNAME(fid) AS 'name',
                                        position,
                                        status
                                    FROM
                                        ccsfif.Committee_Head_Executive
                                    WHERE
                                        position = 1 AND status = 1;";
                            $qr = mysqli_query($dbc, $q);
                            $row = mysqli_fetch_array($qr);

                            if($row['status']==0)
                                echo "<p ><font color='red'> No Assigned Executive Committee for this ongoing period</font></p>";
                            else
                                echo '<p class="form-control-static" placeholder="input name">'.$row['name'].'</p>';
                        ?>
                  </div>
                </div>
                
                <br>
                
                <div class="form-group">
                  <label class="col-sm-4 col-sm-2 control-label"><b>Committee Head</b></label>
                  <div class="col-sm-8">
                      <?php 
                            $q = "SELECT 
                                        idCommittee_Head_Executive as 'id',
                                        GETFACULTYNAME(fid) AS 'name',
                                        position,
                                        status
                                    FROM
                                        ccsfif.Committee_Head_Executive
                                    WHERE
                                        position = 2 AND status = 1;
                                ";
                            
                      
                            $qr = mysqli_query($dbc, $q);
                            $row = mysqli_fetch_array($qr);

                            if($row['status']==0)
                                echo "<p ><font color='red'> No Assigned Executive Committee for this ongoing period</font></p>";
                            else
                                echo '<p class="form-control-static" placeholder="input name">'.$row['name'].'</p>';
                        ?>
                  </div>
                </div>
                
                
                
                    <div class="row">
          <div class="col-lg-12">
            <div class="col-lg-6 col-md-4 col-sm-4 col-xs-12">
              <div class="custom-box">
                <div class="servicetitle">
                  <h4>Analysis</h4>
                  <hr>
                </div>
                  
                  <?php 
                   $query11="
                            SELECT 
                                idcommittee_team,
                                area,
                                GETFACULTYNAME(fid) AS 'name',
                                team,
                                head_team,
                                status
                            FROM
                                ccsfif.committee_team
                            WHERE
                                status = 1 
                                AND area = 3
                                AND  team = 1
                                AND head_team =1
                            ORDER BY team DESC;" ;
                            $qr = mysqli_query($dbc, $query11);
                            $row1 = mysqli_fetch_array($qr);
                  
                  echo "<h5><bold>Head: ".$row1['name']."</bold></h5>";
                  
                  ?>
                
                <ul class="pricing">
                 <?php
                    $query11="
                            SELECT 
                                idcommittee_team,
                                area,
                                GETFACULTYNAME(fid) AS 'name',
                                team,
                                head_team,
                                status
                            FROM
                                ccsfif.committee_team
                            WHERE
                                status = 1 
                                AND area = 3
                                AND  team = 1
                                AND head_team = 0
                            ORDER BY team DESC;" ;
                            

                    $result11=mysqli_query($dbc,$query11);

                    while($row1=mysqli_fetch_array($result11,MYSQLI_ASSOC))
                    {
                        
                        echo "<li>{$row1['name']}</li>";
                        
                   
                    }
                ?>
                </ul>
                <a class="btn btn-theme" href="#">EDIT</a>
              </div>
              <!-- end custombox -->
            </div>
            <!-- end col-4 -->
            <div class="col-lg-6 col-md-4 col-sm-4 col-xs-12">
              <div class="custom-box">
                <div class="servicetitle">
                  <h4>Evaluation</h4>
                  <hr>
                </div>
                  <?php
                    $querycommitteehead="
                            SELECT 
                                idcommittee_team,
                                area,
                                GETFACULTYNAME(fid) AS 'name',
                                team,
                                head_team,
                                status
                            FROM
                                ccsfif.committee_team
                            WHERE
                                status = 1 
                                AND area = 3
                                AND  team = 2
                                AND head_team = 1
                            ORDER BY team DESC;" ;
                  $qr = mysqli_query($dbc, $querycommitteehead);
                            $rowhi = mysqli_fetch_array($qr);
                            
               echo "<h5><bold>Head : </bold>".$rowhi['name']."</h5>";
                    
                    ?>
                <ul class="pricing">
                  <?php
                    $query11="
                            SELECT 
                                idcommittee_team,
                                area,
                                GETFACULTYNAME(fid) AS 'name',
                                team,
                                head_team,
                                status
                            FROM
                                ccsfif.committee_team
                            WHERE
                                status = 1 
                                AND area = 3
                                AND  team = 2
                                AND head_team = 0 
                            ORDER BY team DESC;" ;
                            

                    $result11=mysqli_query($dbc,$query11);

                    while($row1=mysqli_fetch_array($result11,MYSQLI_ASSOC))
                    {
                        
                        echo "<li>{$row1['name']}</li>";
                        
                   
                    }
                ?>
                </ul>
                <a class="btn btn-theme" href="#">add</a>
              </div>
              <!-- end custombox -->
            </div>
            <!-- end col-4 -->
        
            <!-- end col-4 -->
          </div>
          <!--  /col-lg-12 -->
        </div>    

            </div>
            <!-- /content-panel -->
          </div>
          
            
   

	 
          
        <!-- /row -->
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->

    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../../lib/jquery/jquery.min.js"></script>

  <script src="../../lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../../lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../lib/jquery.scrollTo.min.js"></script>
  <script src="../../lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="../../lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="../../lib/common-scripts.js"></script>
  <script type="text/javascript" src="../../lib/gritter/js/jquery.gritter.js"></script>
  <script type="text/javascript" src="../../lib/gritter-conf.js"></script>
  <!--script for this page-->
  <script src="../../lib/sparkline-chart.js"></script>
  <script src="../../lib/zabuto_calendar.js"></script>

  <script type="application/javascript">
    $(document).ready(function() {
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });
    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
  </script>

<script>
    $("#5").addClass("active");
  </script>
</body>

</html>
