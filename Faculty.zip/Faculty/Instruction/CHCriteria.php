<!DOCTYPE html>
<html lang="en">
<?php
    session_start();
        require_once('../../mysql_connect.php');
    if($_SESSION['POSITION_ID']!="P0004" && $_SESSION['POSITION_ID']!="P0003" ) {
          header("Location: http://".$_SERVER['HTTP_HOST'].  dirname($_SERVER['PHP_SELF'])."../login.php"); 
        }
    
    
        
        if (isset($_POST['Submit'])){
            $order = $_POST['order'];
            $name = $_POST['name'];
            $desc = htmlspecialchars($_POST['description']);
            $status = $_POST['status'];
            $id = $_POST['criteriaID'];
            $areaID = $_POST['areaID'];
            
            
            if ($status == "Active"){
                //If Activate
                
                //Get old order number of criteria
                $oldQuery = "SELECT criteria.order as `order` from criteria WHERE criteriaID = $id";
                $oldResult = mysqli_query($dbc, $oldQuery);

                while ($row=mysqli_fetch_array($oldResult)){
                    $oldOrder = $row['order'];
                }
            
                if ($order == ""){
                    //Inactive --> Active, automatically make it the last of the list
                    $max = "SELECT MAX(`criteria`.`order`)+1 AS `last` FROM criteria WHERE areaID = $areaID";
                    $query = mysqli_query($dbc,$max);
                    while ($row=mysqli_fetch_array($query)){
                        $newO = $row['last'];
                    }
                }
                elseif ($order != $oldOrder){
                    //Still active, changing the order
                    //2 -> 5
                    //Make old to new
                    $update1 = "UPDATE `criteria` SET `order` = $oldOrder WHERE `criteria`.`order` =$order AND `criteria`.`areaID` = $areaID";
                    mysqli_query($dbc, $update1);
                    //5 -> 2
                    //Make new t
                    $newO = $order;
                    
                }
                elseif ($order == $oldOrder){
                    $newO = $oldOrder;
                }
                
                $sql = "UPDATE `criteria` SET `criteriaName` = '$name', `order` = '$newO', `criteriaDesc` = '$desc', `status` = '$status' WHERE `criteria`.`criteriaID` = $id";
                mysqli_query($dbc,$sql);
            }
            elseif ($status == "Inactive"){
                
                //Get old order number of criteria
                $oldQuery = "SELECT criteria.order as `order`, criteria.status as `status` from criteria WHERE criteriaID = $id";
                $oldResult = mysqli_query($dbc, $oldQuery);

                while ($row=mysqli_fetch_array($oldResult)){
                    $oldOrder = $row['order'];
                    $oldStatus = $row['status'];
                }
                
                if ($status != $oldStatus){
                
                $sql = "UPDATE `criteria` SET `criteriaName` = '$name', `order` = 0, `criteriaDesc` = '$desc', `status` = '$status' WHERE `criteria`.`criteriaID` = $id";
                mysqli_query($dbc,$sql);
                
                $sql2 = "UPDATE `criteria` SET `order` = `order`-1 WHERE `order` > $oldOrder AND `areaID` = $areaID";
                mysqli_query($dbc, $sql2);
                }
                elseif ($status == $oldStatus){
                    
                }
            }
            
        }
    elseif (isset($_POST['delete'])){
        $id = $_POST['criteriaID2'];
        
        $sql = "UPDATE `criteria` SET `status` = 'Deleted' WHERE `criteria`.`criteriaID` = $id";
        mysqli_query($dbc,$sql);
    }
    elseif (isset($_POST['add'])){
        $name = $_POST['criteriaName'];
        $desc = $_POST['criteriaDesc'];
        $areaID = $_POST['areaID'];

        $max = "SELECT MAX(`criteria`.`order`)+1 AS `last` FROM criteria WHERE areaID = $areaID AND status = 'Active'";
        $query = mysqli_query($dbc,$max);
        while ($row=mysqli_fetch_array($query)){
            $newO = $row['last'];
        }
        
        $sql2 = "INSERT INTO `criteria` (`criteriaID`, `criteriaName`, `order`, `criteriaDesc`, `status`, `areaID`) VALUES (NULL, '$name', '$newO', '$desc', 'Active', '$areaID')";
        mysqli_query($dbc, $sql2);
        
    }
?>


<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>CCS- Accreditation Management System</title>

 <!-- Favicons -->
  <link href="../../../img/logodlsu.png" rel="icon">
  <link href="../../../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../../../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="../../../css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="../../../lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="../../../css/style.css" rel="stylesheet">
  <link href="../../../css/style-responsive.css" rel="stylesheet">
  <script src="../../../lib/chart-master/Chart.js"></script>

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
  


<?php 

      require_once("sidetopbar.php");
      

    ?> 
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        <h3>
          <i class="fa fa-angle-right"></i> Evaluative Criteria 
            <a href="CHAddCriteria.php"><button type="button" class="btn btn-success" name="add"><i class="fa fa-plus"></i>&nbsp;Add New</button> </a>
        </h3>
          
          
          <?php
          
            $query = "Select * from area";
            $result = mysqli_query($dbc, $query);
            while ($row = mysqli_fetch_array($result)) {
                $ID = $row['areaID'];
                
          
          ?>
        
        <!-- row -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> <?php echo "{$row['areaName']}<br>"; ?></h4>
                <hr>
                <thead>
                  <tr>
                    <th><i class="fa fa-bullhorn"></i> Order</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Criteria Name</th>
                    <th><i class="fa fa-bookmark"></i> Description</th>
                    <th><i class=" fa fa-edit"></i> Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                    $query2 = "SELECT *, criteria.order AS 'order', area.areaName AS 'areaName' FROM criteria INNER JOIN area ON criteria.areaID = area.areaID WHERE status = 'Active' AND area.areaID = ".$ID." ORDER BY `order`";
                    $result2 = mysqli_query($dbc, $query2);
                    while ($row = mysqli_fetch_array($result2)){
                        $criteriaID = $row['criteriaID'];
                        $roworder = $row['order'];
                    ?>
                  <tr>
                    <td>
                      <?php echo $row['order']; ?>
                    </td>
                    <td><?php echo $row['criteriaName']; ?></td>
                    <td><?php echo $row['criteriaDesc']; ?></td>
                    <td><span class="label label-success label-mini">Active</span></td>
                    <td>
                        <a href="CHEditCriteria.php?id=<?php echo $criteriaID;?>" class="btn btn-primary btn-xs">Edit</a>
                    </td>
                  </tr>
                    <?php
                    }
                        ?>
                    <?php
                    $query3 = "SELECT *, area.areaName AS 'areaName' FROM criteria INNER JOIN area ON criteria.areaID = area.areaID WHERE status = 'Inactive' AND area.areaID = ".$ID;
                    $result3 = mysqli_query($dbc, $query3);
                    while ($row = mysqli_fetch_array($result3)){ 
                        $criteriaID2 = $row['criteriaID'];
                    ?>
                  <tr>
                    <td>
                    </td>
                    <td><?php echo $row['criteriaName']; ?></td>
                    <td><?php echo $row['criteriaDesc']; ?></td>
                    <td><span class="label label-danger label-mini">Inactive</span></td>
                    <td>
                        <a href="CHEditCriteria.php?id=<?php echo $criteriaID2;?>" class="btn btn-primary btn-xs">Edit</a>
                    </td>
                  </tr>
                    <?php
                    }
                        ?>
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->
          
          <?php
            
        }
          
          ?>
          
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->

    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../../../lib/jquery/jquery.min.js"></script>

  <script src="../../../lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../../../lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../../lib/jquery.scrollTo.min.js"></script>
  <script src="../../../lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="../../../lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="../../../lib/common-scripts.js"></script>
  <script type="text/javascript" src="../../../lib/gritter/js/jquery.gritter.js"></script>
  <script type="text/javascript" src="../../../lib/gritter-conf.js"></script>
  <!--script for this page-->
  <script src="../../../lib/sparkline-chart.js"></script>
  <script src="../../../lib/zabuto_calendar.js"></script>

  <script type="application/javascript">
    $(document).ready(function() {
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });
    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
  </script>
</body>

</html>
